@extends('layout')
 
@section('content')

    <br>
    @if (count($errors) > 0)
	<div class="alert alert-danger">
		<strong>Whoops!</strong> There were some problems with your input.<br><br>
		<ul>
			@foreach ($errors->all() as $error)
				<li>{{ $error }}</li>
			@endforeach
		</ul>
	</div>
@endif
 
    <h1 class="title"> Create Cars </h1>
 
    <form method="POST" action="/uploadsql" enctype="multipart/form-data">
    @csrf
 
        <div class="field">
 
            <label class="lable" for="name">Car Name </label>
 
            <div class="control">
 
                <input type="text" class="input" name="imagename" placeholder="Title" value="" required>
        
            </div>
       
        </div>
    
        <div class="field">
 
            <div class="control">
                 <input type="file" class="form-control-file" name="fileToUpload" aria-describedby="fileHelp">
            </div>
         </div>   
       
        <div class="field">
 
            <div class="control">
 
                <button type="submit" class="button is-link">Create Car</button>
 
            </div>
 
        </div>
 
    </form> 
 
 @endsection
